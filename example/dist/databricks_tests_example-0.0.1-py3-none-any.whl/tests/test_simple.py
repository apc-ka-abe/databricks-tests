import pytest

class TestSimple():
    def test_simple(self):
        pass
